import { Injectable } from '@angular/core';

@Injectable()
export class ApplicationStateService {

    public postLoginRouter: any;

    constructor() { }
}
