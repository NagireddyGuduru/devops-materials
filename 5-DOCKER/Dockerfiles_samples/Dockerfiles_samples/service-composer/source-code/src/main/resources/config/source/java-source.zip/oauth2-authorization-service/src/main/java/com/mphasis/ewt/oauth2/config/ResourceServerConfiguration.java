package com.mphasis.ewt.oauth2.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;
import org.springframework.security.oauth2.config.annotation.web.configuration.ResourceServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configurers.ResourceServerSecurityConfigurer;

@Configuration
@EnableResourceServer
public class ResourceServerConfiguration extends ResourceServerConfigurerAdapter {
	
	@Value("${security-service.resource-id:SECURITY_SERVICE}")
	private String resourceId;
	
	@Override
	public void configure(final ResourceServerSecurityConfigurer resources) {
		resources.resourceId(resourceId);
	}
}
