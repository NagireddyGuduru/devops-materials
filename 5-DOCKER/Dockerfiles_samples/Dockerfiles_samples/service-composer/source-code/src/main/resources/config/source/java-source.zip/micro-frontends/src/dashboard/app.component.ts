import { Component } from '@angular/core';

@Component({
  selector: 'mui-dashboard',
  templateUrl: './src/dashboard/app.component.html',
  styleUrls: ['./src/dashboard/app.component.css']

})
export class AppComponent {
}
