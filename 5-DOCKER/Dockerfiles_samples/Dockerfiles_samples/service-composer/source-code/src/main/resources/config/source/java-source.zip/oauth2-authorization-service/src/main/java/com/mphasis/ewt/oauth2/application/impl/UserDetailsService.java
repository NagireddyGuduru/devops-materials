package com.mphasis.ewt.oauth2.application.impl;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.mphasis.ewt.oauth2.domain.model.security.IUserRepository;
import com.mphasis.ewt.oauth2.domain.model.security.User;

@Service("userDetailsService")
public class UserDetailsService implements org.springframework.security.core.userdetails.UserDetailsService {

	@Autowired
	private IUserRepository userRepository;
	
	@Override
	public UserDetails loadUserByUsername(final String userName) throws UsernameNotFoundException {
		final User user = userRepository.findOneByUserName(userName);
		return new UserPrincipal(
				user.getUserName(), 
				user.getPassword(), 
				true /*enabled*/, 
				true /*accountNonExpired*/, 
				true /*credentialsNonExpired*/, 
				true /*accountNonLocked*/, 
				getGrantedAuthorities(user),
				user.getFirstName(),
				user.getLastName(),
				user.getEmail());
	}
	
	private List<GrantedAuthority> getGrantedAuthorities(final User user) {
		return user.getUserRoles().stream()
					.map(aRole -> new SimpleGrantedAuthority("ROLE_" + aRole.getType()))
					.collect(Collectors.toList());
	}
}


class UserPrincipal extends org.springframework.security.core.userdetails.User {
	
	private static final long serialVersionUID = 1L;
	private String firstName, lastName, email; 

	public UserPrincipal(String username, String password, boolean enabled, boolean accountNonExpired,
			boolean credentialsNonExpired, boolean accountNonLocked,
			Collection<? extends GrantedAuthority> authorities, 
			String firstName, String lastName, String email) {
		super(username, password, enabled, accountNonExpired, credentialsNonExpired, accountNonLocked, authorities);
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public String getEmail() {
		return email;
	}
	
	
	
}