package com.mphasis.ewt.gateway.filters.pre;

import static org.springframework.cloud.netflix.zuul.filters.support.FilterConstants.DEBUG_FILTER_ORDER;
import static org.springframework.cloud.netflix.zuul.filters.support.FilterConstants.PRE_TYPE;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;

@Component
public class Oauth2AuthorizationTokenFilter extends ZuulFilter {

	private static final String HEADER_AUTHORIZATION = "Authorization";
	private static final String HEADER_AUTHORIZATION_BEARER = "bearer ";
	
	@Value("${accessTokenCookieName:access_token}")
	private String accessTokenCookieName;
	
	@Override
	public boolean shouldFilter() {
		return true;
	}

	@Override
	public int filterOrder() {
		return DEBUG_FILTER_ORDER;
	}

	@Override
	public String filterType() {
		return PRE_TYPE;
	}
	
	@Override
	public Object run() {
		final RequestContext context = RequestContext.getCurrentContext();
		final HttpServletRequest request = context.getRequest();
		String accessToken = null;
		if (null != request.getCookies()) {
			for (Cookie cookie: request.getCookies()) {
				if (accessTokenCookieName.equals(cookie.getName())) {
					accessToken = cookie.getValue();
					break;
				}
			}
		}
		if (null != accessToken) {
			context.addZuulRequestHeader(HEADER_AUTHORIZATION, HEADER_AUTHORIZATION_BEARER + accessToken);
		}
		return null;
	}
}
