package com.mphasis.ewt.demoservice.samples;

import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;

import org.springframework.stereotype.Service;
import org.stagemonitor.core.metrics.MonitorGauges;

import com.codahale.metrics.annotation.ExceptionMetered;
import com.codahale.metrics.annotation.Gauge;
import com.codahale.metrics.annotation.Metered;
import com.codahale.metrics.annotation.Timed;

@Service
@MonitorGauges
public class ApplicationMertricsService {
	
	private static final int THREAD_POOL_SIZE = 3;
	private static ThreadPoolExecutor executorService = (ThreadPoolExecutor) Executors.newFixedThreadPool(THREAD_POOL_SIZE);;
	
	@Timed
	@Metered
	@ExceptionMetered
	public void randomTask() throws Exception {
		System.out.printf("[%s], I am random piece of work and i will take a while to complete.\n", Thread.currentThread().getId());
		long randomWait = Math.round((Math.random() * 5));
		Thread.sleep(randomWait * 1000);
		if (randomWait < 1) {
			throw new RuntimeException("The wait was too little to be thrown as an error.");
		}
		System.out.printf("[%s] I am done after " + randomWait + " seconds.\n", Thread.currentThread().getId());
	}
	
	public void submitAJob() {
		executorService.submit(new Runnable() {
			@Override
			public void run() {
				try {
					long randomWait = Math.round((Math.random() * 10));
					Thread.sleep(randomWait * 1000);
					if (randomWait < 3) {
						throw new RuntimeException("The wait was too little to be thrown as an error.");
					}
					System.out.printf("[%s] Job am done after " + randomWait + " seconds.\n", Thread.currentThread().getId());
				} catch(Exception e) {
					throw new RuntimeException(e);
				}
			}
		});
	}
	
	
	@Gauge(name = "NumberOfJobsRunning")
    public int getNumberOfJobsRunning() {
        return executorService.getActiveCount();
    }    
}
