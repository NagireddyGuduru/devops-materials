import React from 'react';

export default class Root extends React.Component {
    render() {
        return (
            <div>
                <h2>Service Monitoring</h2>
                <hr/>
                <h3>This was rendered by an application written in React.</h3>
			</div>
        );
    }
}
