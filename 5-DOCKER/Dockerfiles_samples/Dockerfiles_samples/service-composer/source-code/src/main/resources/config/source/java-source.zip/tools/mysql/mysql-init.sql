CREATE DATABASE IF NOT EXISTS myapp_db;

USE myapp_db;