package com.mphasis.ewt.demoservice.interfaces;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.ewt.demoservice.samples.ApplicationMertricsService;

@RestController
@RequestMapping("/metrics")
public class ApplicationMertricsEndpoint {

	@Autowired
	private ApplicationMertricsService service;
	
	@GetMapping("/randomTask")
	public String invokeRandomTask() throws Exception {
		service.randomTask();
		return "TaskInvoked";
	}
	
	@GetMapping("/submitJob")
	public String submitAJob() throws Exception {
		service.submitAJob();;
		return "JobSubmitted";
	}
}
