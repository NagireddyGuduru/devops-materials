package com.mphasis.ewt.oauth2.interfaces;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.oauth2.provider.token.ConsumerTokenServices;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/user")
public class AuthenticationRestService {

	@Autowired
	private ConsumerTokenServices consumerTokenServices;

	@RequestMapping("/me")
	public Principal user(final Principal principal) {
		return principal;
	}
	
	@RequestMapping(value = "/invalidateToken", method = RequestMethod.POST)
	public void invalidateToken(@RequestParam("access_token") String access_token) {
		consumerTokenServices.revokeToken(access_token);
	}
}
