export const environment = {
    userServiceUri: 'http://{{loadBalancerAddress}}/auth-service/users'
};
