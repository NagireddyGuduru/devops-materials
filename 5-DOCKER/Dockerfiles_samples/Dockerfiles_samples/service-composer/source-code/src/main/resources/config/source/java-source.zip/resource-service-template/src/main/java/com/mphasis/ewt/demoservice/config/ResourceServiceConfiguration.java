package com.mphasis.ewt.demoservice.config;

import java.util.Collections;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;
import org.springframework.security.oauth2.config.annotation.web.configuration.ResourceServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configurers.ResourceServerSecurityConfigurer;
import org.springframework.security.oauth2.provider.token.RemoteTokenServices;
import org.springframework.security.oauth2.provider.token.ResourceServerTokenServices;
import org.springframework.web.client.RestTemplate;

@Configuration
@EnableResourceServer
public class ResourceServiceConfiguration extends ResourceServerConfigurerAdapter {

	@Value("${demo-service.resource-id}")
	private String resourceId;
	
	@Value("${oauth2.clientId}")
	private String oauth2ClientId;
	
	@Value("${oauth2.clientSecret}")
	private String oauth2ClientSecret;
	
	@Value("${oauth2.tokenInfoUri}")
	private String oauth2TokenCheckUrl;
	
	public ResourceServerTokenServices tokenService() {
		final RemoteTokenServices tokenService = new RemoteTokenServices();
		tokenService.setClientId(oauth2ClientId);
		tokenService.setClientSecret(oauth2ClientSecret);
		tokenService.setCheckTokenEndpointUrl(oauth2TokenCheckUrl);
		return tokenService;
	}
	
	@Bean
	public RestTemplate oauth2RestTemplate() {
		final RestTemplate restTemplate = new RestTemplate();
		restTemplate.setInterceptors(Collections.singletonList(new Oauth2AuthorizationHeaderRequestInterceptor()));
		return restTemplate;
	}
	
	@Override
	public void configure(final ResourceServerSecurityConfigurer resources) {
		resources
			.resourceId(resourceId)
			.tokenServices(tokenService());
	}
	
	@Override
	public void configure(final HttpSecurity http) throws Exception {
		super.configure(http);
		http.authorizeRequests()
			.antMatchers("/admin/**").access("hasRole('Administrator')");
	}
}
