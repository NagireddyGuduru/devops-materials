import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-statistics',
    templateUrl: './src/dashboard/statistics/statistics.component.html',
    styleUrls: ['./src/dashboard/statistics/statistics.component.css']
})
export class StatisticsComponent implements OnInit {
    constructor() { }

    ngOnInit() {
    }
}
