export const environment = {
    // <block-oauth2-authorization-service-start>
    loginUrl: 'http://localhost',
    userInfoUri: 'http://localhost/auth-service/user/me',
    // <block-oauth2-authorization-service-end>
    production: false
};
