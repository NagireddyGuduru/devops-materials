export const environment = {
    userServiceUri: 'http://localhost/auth-service/users'
};
