export const environment = {
    userServiceUri: 'http://localhost:8000/auth-service/users'
};
