package com.mphasis.ewt.demoservice.config;

//<block-edge-service-zuul-start>
import javax.servlet.ServletContext;
//<block-edge-service-zuul-end>

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.google.common.base.Predicate;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
//<block-edge-service-zuul-start>
import springfox.documentation.spring.web.paths.RelativePathProvider;
//<block-edge-service-zuul-end>
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
@EnableSwagger2
public class ApiDocumentationConfiguration {

	//<block-edge-service-zuul-start>
	@Autowired
	private ServletContext servletContext;
	//<block-edge-service-zuul-end>
	
	@Bean
	public Docket devopsApi() {
		return new Docket(DocumentationType.SWAGGER_2)
				//<block-edge-service-zuul-start>
				.pathProvider(new RelativePathProvider(servletContext) {
			        @Override
			        public String getApplicationBasePath() {
			            return "/";
			        }
			    })
				//<block-edge-service-zuul-end>
				.apiInfo(apiInfo())
				.select()
				.apis(RequestHandlerSelectors.any())
				.paths(paths())
				.build();
	}
	
	public ApiInfo apiInfo() {
		return new ApiInfoBuilder()
				.title("Microservices Accelerator Service Template")
				.description("A template to build business servives")
				.contact(new Contact("Mohideen Rasik", null, "mohideen.rasik@mphasis.com"))
				.version("0.1")
				.build();
	}
	
	private Predicate<String> paths() {
		return PathSelectors.regex("/.*");
	}
}
