export const environment = {
    userServiceUri: 'http://{{loadBalancerAddress}}:8000/auth-service/users'
};
